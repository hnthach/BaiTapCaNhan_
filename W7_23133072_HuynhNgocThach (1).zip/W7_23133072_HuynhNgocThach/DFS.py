import pygame
import time

# Khởi tạo Pygame
pygame.init()

# Kích thước cửa sổ và ô
WIDTH, HEIGHT = 300, 300
TILE_SIZE = WIDTH // 3
FONT = pygame.font.Font(None, 50)

# Màu sắc
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)

# Trạng thái xuất phát và đích
start_state = [[2, 6, 5], [8, 7, 0], [4, 3, 1]]
goal_state = [[1, 2, 3], [4, 5, 6], [7, 8, 0]]

def draw_board(screen, state):
    """Vẽ bảng 8-puzzle với trạng thái hiện tại"""
    screen.fill(WHITE)
    for row in range(3):
        for col in range(3):
            num = state[row][col]
            if num != 0:
                pygame.draw.rect(screen, BLUE, (col * TILE_SIZE, row * TILE_SIZE, TILE_SIZE, TILE_SIZE))
                text = FONT.render(str(num), True, WHITE)
                screen.blit(text, (col * TILE_SIZE + TILE_SIZE // 3, row * TILE_SIZE + TILE_SIZE // 4))
    pygame.display.update()

def find_blank(state):
    """Tìm vị trí của ô trống (0)"""
    for row in range(3):
        for col in range(3):
            if state[row][col] == 0:
                return row, col

def get_neighbors(state):
    """Sinh các trạng thái con có thể đi từ trạng thái hiện tại"""
    row, col = find_blank(state)
    moves = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    neighbors = []
    for dr, dc in moves:
        new_row, new_col = row + dr, col + dc
        if 0 <= new_row < 3 and 0 <= new_col < 3:
            new_state = [row[:] for row in state]  # Sao chép trạng thái hiện tại
            new_state[row][col], new_state[new_row][new_col] = new_state[new_row][new_col], new_state[row][col]
            neighbors.append(new_state)
    return neighbors

def count_inversions(state):
    """Đếm số lượng nghịch đảo trong trạng thái"""
    inversions = 0
    flat_state = [num for row in state for num in row if num != 0]
    for i in range(len(flat_state)):
        for j in range(i + 1, len(flat_state)):
            if flat_state[i] > flat_state[j]:
                inversions += 1
    return inversions

def is_solvable(start, goal):
    """Kiểm tra xem bài toán có lời giải hay không"""
    start_inversions = count_inversions(start)
    goal_inversions = count_inversions(goal)
    return start_inversions % 2 == goal_inversions % 2

def dfs_solve(start, goal, depth_limit=50):
    """Tìm lời giải bằng DFS với giới hạn độ sâu"""
    stack = [(start, [])]
    visited = set()

    while stack:
        state, path = stack.pop()
        state_tuple = tuple(map(tuple, state))  # Chuyển trạng thái thành tuple để lưu vào set

        if state_tuple in visited:
            continue
        visited.add(state_tuple)

        if state == goal:
            return path + [state]

        if len(path) < depth_limit:  # Giới hạn độ sâu
            for neighbor in get_neighbors(state):
                stack.append((neighbor, path + [state]))

    return []  # Không tìm thấy lời giải

def main():
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("8-Puzzle DFS")

    # Kiểm tra xem bài toán có lời giải hay không
    if not is_solvable(start_state, goal_state):
        print("Bài toán không có lời giải!")
        return

    # Tìm lời giải bằng DFS
    solution = dfs_solve(start_state, goal_state, depth_limit=100)
    print("Lời giải:", solution)

    if not solution:
        print("Không tìm thấy lời giải")
        return

    # Hiển thị lời giải
    for state in solution:
        draw_board(screen, state)
        pygame.event.get()  # Xử lý sự kiện 1 lần trong vòng lặp
        time.sleep(0.5)

    pygame.time.wait(5000)  # Giữ cửa sổ trong 5 giây trước khi thoát
    pygame.quit()

if __name__ == "__main__":
    main()
