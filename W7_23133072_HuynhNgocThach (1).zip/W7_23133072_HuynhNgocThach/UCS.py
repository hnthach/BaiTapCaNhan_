import pygame
import time
import heapq

# Khởi tạo Pygame
pygame.init()

# Kích thước cửa sổ và ô
WIDTH, HEIGHT = 300, 300
TILE_SIZE = WIDTH // 3
FONT = pygame.font.Font(None, 50)

# Màu sắc
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)

# Trạng thái xuất phát và đích
start_state = [[2, 6, 5], [8, 7, 0], [4, 3, 1]]
goal_state = [[1, 2, 3], [4, 5, 6], [7, 8, 0]]

def draw_board(screen, state):
    """Vẽ bảng 8-puzzle với trạng thái hiện tại"""
    screen.fill(WHITE)
    for row in range(3):
        for col in range(3):
            num = state[row][col]
            if num != 0:
                pygame.draw.rect(screen, BLUE, (col * TILE_SIZE, row * TILE_SIZE, TILE_SIZE, TILE_SIZE))
                text = FONT.render(str(num), True, WHITE)
                screen.blit(text, (col * TILE_SIZE + TILE_SIZE//3, row * TILE_SIZE + TILE_SIZE//4))
    pygame.display.update()
    pygame.event.get()
    time.sleep(0.5)  # Dừng 0.5s giữa các bước

def find_blank(state):
    """Tìm vị trí của ô trống (0)"""
    for row in range(3):
        for col in range(3):
            if state[row][col] == 0:
                return row, col

def get_neighbors(state):
    """Sinh các trạng thái con có thể đi từ trạng thái hiện tại"""
    row, col = find_blank(state)
    moves = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    neighbors = []
    for dr, dc in moves:
        new_row, new_col = row + dr, col + dc
        if 0 <= new_row < 3 and 0 <= new_col < 3:
            new_state = [row[:] for row in state]
            new_state[row][col], new_state[new_row][new_col] = new_state[new_row][new_col], new_state[row][col]
            neighbors.append(new_state)
    return neighbors

def ucs_solve(start, goal):
    """Tìm lời giải bằng Uniform Cost Search (UCS)"""
    priority_queue = [(0, start, [])]  # (cost, state, path)
    visited = set()
    
    while priority_queue:
        cost, state, path = heapq.heappop(priority_queue)
        state_tuple = tuple(map(tuple, state))
        
        if state_tuple in visited:
            continue
        visited.add(state_tuple)
        
        if state == goal:
            return path + [state]
        
        for neighbor in get_neighbors(state):
            heapq.heappush(priority_queue, (cost + 1, neighbor, path + [state]))
    
    return []

def main():
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("8-Puzzle UCS")
    
    solution = ucs_solve(start_state, goal_state)
    print("Lời giải:", solution)
    
    if not solution:
        print("Không tìm thấy lời giải")
        return
    
    for state in solution:
        draw_board(screen, state)
        pygame.event.get()
        time.sleep(0.5)
    
    pygame.time.wait(5000)  # Giữ cửa sổ trong 5 giây trước khi thoát
    pygame.quit()

if __name__ == "__main__":
    main()
